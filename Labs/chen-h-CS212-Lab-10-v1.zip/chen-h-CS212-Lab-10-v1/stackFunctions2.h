#ifndef stackFunctions2_H
#define stackFunctions2_H
#include <stdio.h>
/*------------------------------------------------Prototypes------------------------------------------------*/
double PushStack2(double X);
double PopStack2(void);
double TopStack2(void);
double isFullStack2(void);

#endif
