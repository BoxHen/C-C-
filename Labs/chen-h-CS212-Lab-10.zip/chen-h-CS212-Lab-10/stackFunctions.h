#ifndef stackFunctions_H
#define stackFunctions_H
#include <stdio.h>
/*------------------------------------------------Prototypes------------------------------------------------*/
int PushStack(char X);
char PopStack();
char TopStack(void);
int isFullStack(void);

#endif
