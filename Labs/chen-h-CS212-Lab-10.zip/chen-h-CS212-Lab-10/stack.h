
typedef struct stackNodeTag{
	char item;
	struct stackNodeTag *next;
}stackNode;

stackNode *anchorStack;
stackNode *anchorStack2;
