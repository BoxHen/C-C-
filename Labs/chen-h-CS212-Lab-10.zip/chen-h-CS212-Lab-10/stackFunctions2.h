#ifndef stackFunctions2_H
#define stackFunctions2_H
#include <stdio.h>
/*------------------------------------------------Prototypes------------------------------------------------*/
int PushStack2(int X);
int PopStack2();
int TopStack2(void);
int isFullStack2(void);

#endif
