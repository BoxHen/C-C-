
typedef struct stackNodeTag2{
	double item;
	struct stackNodeTag2 *next;
}stackNode2;

stackNode2 *anchorStack2;
